# To run the project:

- clone the project to your local with git clone
- npm install / yarn add
- npm start or yarn start

# Deploy : 

https://movieapp-react-sule.netlify.app/

<h2 align="center">Happy Coding  ✍</h2>




